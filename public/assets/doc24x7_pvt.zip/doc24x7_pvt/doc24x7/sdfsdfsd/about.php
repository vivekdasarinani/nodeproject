<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

<title>Docpro - HTML 5 Template Preview</title>

<!-- Fav Icon -->
<link rel="icon" href="assets/images/favicon.ico" type="image/x-icon">

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Jost:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

<!-- Stylesheets -->
<link href="assets/css/font-awesome-all.css" rel="stylesheet">
<link href="assets/css/flaticon.css" rel="stylesheet">
<link href="assets/css/owl.css" rel="stylesheet">
<link href="assets/css/bootstrap.css" rel="stylesheet">
<link href="assets/css/jquery.fancybox.min.css" rel="stylesheet">
<link href="assets/css/animate.css" rel="stylesheet">
<link href="assets/css/color.css" rel="stylesheet">
<link href="assets/css/style.css" rel="stylesheet">
<link href="assets/css/responsive.css" rel="stylesheet">

</head>


<!-- page wrapper -->
<body>

    <div class="boxed_wrapper">

        <!-- preloader -->
        <div class="preloader"></div>
        <!-- preloader -->


        <!-- main header -->
        

            <?php require_once('header.php'); ?>




        <!-- about-style-two -->
        <section class="about-style-two">
            <div class="auto-container">
                <div class="row align-items-center clearfix">
				<div class="col-lg-6 col-md-12 col-sm-12 image-column">
                        <div class="image_block_3">
                            <div class="image-box">
                                <div class="pattern">
                                    <div class="pattern-1" style="background-image: url(assets/images/shape/shape-49.png);"></div>
                                    <div class="pattern-2" style="background-image: url(assets/images/shape/shape-50.png);"></div>
                                    <div class="pattern-3"></div>
                                </div>
                                <figure class="image image-1 paroller"><img src="assets/images/resource/about-4.jpg" alt=""></figure>
                                <figure class="image image-2 paroller-2"><img src="assets/images/resource/about-3.jpg" alt=""></figure>
                                <div class="image-content">
                                    <figure class="icon-box"><img src="assets/images/icons/icon-8.png" alt=""></figure>
                                    <span>Appointment With</span>
                                    <h4>Specialist</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                        <div class="content_block_1">
                            <div class="content-box mr-50">
                                <div class="sec-title">
                                    <p>About Doc24X7</p>
                                    <!--<h2>Bring care to your home with one click</h2>-->
                                </div>
                                <div class="text">
                                    <p>Our Doc24x7 gives primary care which is look after by professional MBBS and physician doctors who provides holistic care and assessment for non-emergent conditions that can typically be treated and identifies early signs of multiple diseases and conditions through a regular health check-up like fever, cough, BP check-up and other vitals.</p>
									<p>To acquire trust of a family with support and intensive care for the family members and by providing healthcare medical services of the best quality. we also provide services like health insurances to help a patient family securely affordable to relive a life</p>
									<p><b>“ No matter what your size and health condition is, we a new family member take care by prescribing you a healthy medication, healthy diet, exercises which makes a healthy family ”</b></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
			
        </section>
		<section class="about-style-two">
			<div class="auto-container">
                <div class="row align-items-center clearfix">
                    <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                        <div class="content_block_1">
                            <div class="content-box mr-50">
                                <div class="sec-title">
                                    <!--<p>About Doc24X7</p>-->
                                    <h2>10 Reasons Why You Need A Primary Care Doctor</h2>
                                </div>
                                <ul class="list-style-one clearfix">
                                    <li>Holistic health care</li>
                                    <li>Better manage chronic diseases</li>
                                    <li>Higher level of comfort</li>
                                    <li>Transparency of entire health history</li>
                                    <li>Lower overall health costs</li>
                                    <li>Routine screenings</li>
                                    <li>Catch health issues early</li>
                                    <li>Referrals to other medical specialists</li>
                                    <li>Decrease in hospital and ER visits</li>
                                    <li>Better patient-provider communication</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-sm-12 image-column">
                        <div class="image_block_3">
                            <div class="image-box">
                                <div class="pattern">
                                    <div class="pattern-1" style="background-image: url(assets/images/shape/shape-49.png);"></div>
                                    <div class="pattern-2" style="background-image: url(assets/images/shape/shape-50.png);"></div>
                                    <div class="pattern-3"></div>
                                </div>
                                <figure class="image image-1 paroller"><img src="assets/images/resource/about-4.jpg" alt=""></figure>
                                <figure class="image image-2 paroller-2"><img src="assets/images/resource/about-3.jpg" alt=""></figure>
                                <div class="image-content">
                                    <figure class="icon-box"><img src="assets/images/icons/icon-8.png" alt=""></figure>
                                    <span>Appointment With</span>
                                    <h4>Specialist</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- about-style-two end -->


        <!-- agent-section 
        <section class="agent-section">
            <div class="auto-container">
                <div class="inner-container bg-color-2">
                    <div class="row clearfix">
                        <div class="col-lg-6 col-md-12 col-sm-12 left-column">
                            <div class="content_block_3">
                                <div class="content-box">
                                    <h3>Emergency call</h3>
                                    <div class="support-box">
                                        <div class="icon-box"><i class="fas fa-phone"></i></div>
                                        <span>Telephone</span>
                                        <h3><a href="tel:11165458856">+(111) 65_458_856</a></h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-12 col-sm-12 right-column">
                            <div class="content_block_4">
                                <div class="content-box">
                                    <h3>Sign up for Email</h3>
                                    <form action="index.html" method="post" class="subscribe-form">
                                        <div class="form-group">
                                            <input type="email" name="email" placeholder="Your Email" required="">
                                            <button type="submit" class="theme-btn-one">Submit now<i class="icon-Arrow-Right"></i></button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
         agent-section -->


        <!-- main-footer -->
        <?php require_once('footer.php'); ?>
        <!-- main-footer end -->


        <!--Scroll to top-->
        <button class="scroll-top scroll-to-target" data-target="html">
            <span class="fa fa-arrow-up"></span>
        </button>
    </div>


    <!-- jequery plugins -->
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/wow.js"></script>
    <script src="assets/js/validation.js"></script>
    <script src="assets/js/jquery.fancybox.js"></script>
    <script src="assets/js/appear.js"></script>
    <script src="assets/js/scrollbar.js"></script>
    <script src="assets/js/tilt.jquery.js"></script>
    <script src="assets/js/jquery.paroller.min.js"></script>
    <script src="assets/js/jquery.nice-select.min.js"></script>

    <!-- main-js -->
    <script src="assets/js/script.js"></script>

</body><!-- End of .page_wrapper -->
</html>
